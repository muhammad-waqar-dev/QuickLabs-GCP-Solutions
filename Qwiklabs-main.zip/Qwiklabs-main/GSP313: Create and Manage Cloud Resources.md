### GSP313: Create and Manage Cloud Resources :-

----------------------------------------------------------------------------------------------------------------------------------------------

We have collaborated with CourseIntern Team for code snippets of the labs.

Please Go To : [GSP313: Create and Manage Cloud Resources](https://www.courseintern.com/post/qwiklabs/challenge-labs/gsp313-create-and-manage-cloud-resources/)

YouTube Video Solution : [Click Here](https://bit.ly/3vEgCAz)

----------------------------------------------------------------------------------------------------------------------------------------------
