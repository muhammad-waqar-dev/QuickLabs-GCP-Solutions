### GSP302: Configure a Firewall and a Startup Script with Deployment Manager :-

----------------------------------------------------------------------------------------------------------------------------------------------

We have collaborated with CourseIntern Team for code snippets of the labs.

Please Go To : [GSP302: Configure a Firewall and a Startup Script with Deployment Manager](https://www.courseintern.com/post/qwiklabs/challenge-labs/gsp302-configure-a-firewall-and-a-startup-script-with-deployment-manager/)

YouTube Video Solution : [Click Here](https://youtu.be/hRjpgVVIcpA)

----------------------------------------------------------------------------------------------------------------------------------------------
