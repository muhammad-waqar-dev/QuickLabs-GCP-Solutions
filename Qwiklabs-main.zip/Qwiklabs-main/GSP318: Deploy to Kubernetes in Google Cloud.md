### GSP318: Deploy to Kubernetes in Google Cloud :-

----------------------------------------------------------------------------------------------------------------------------------------------

We have collaborated with CourseIntern Team for code snippets of the labs.

Please Go To : [GSP318: Deploy to Kubernetes in Google Cloud](https://www.courseintern.com/post/qwiklabs/challenge-labs/gsp318-deploy-to-kubernetes-in-google-cloud/)

YouTube Video Solution : [Click Here](https://bit.ly/3eApoK4)

----------------------------------------------------------------------------------------------------------------------------------------------
