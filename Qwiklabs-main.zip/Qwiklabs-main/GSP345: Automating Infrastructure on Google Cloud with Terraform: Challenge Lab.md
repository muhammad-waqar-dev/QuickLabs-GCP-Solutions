### GSP345: Automating Infrastructure on Google Cloud with Terraform: Challenge Lab :-

----------------------------------------------------------------------------------------------------------------------------------------------

We have collaborated with CourseIntern Team for code snippets of the labs.

Please Go To : [GSP345: Automating Infrastructure on Google Cloud with Terraform: Challenge Lab](https://www.courseintern.com/post/qwiklabs/challenge-labs/gsp345-automating-infrastructure-on-google-cloud-with-terraform/)

YouTube Video Solution : [Click Here](https://youtu.be/0v-46Fpp6P4)

----------------------------------------------------------------------------------------------------------------------------------------------
