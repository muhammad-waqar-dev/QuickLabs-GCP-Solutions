### GSP305: Scale Out and Update a Containerized Application on a Kubernetes Cluster :-

----------------------------------------------------------------------------------------------------------------------------------------------

We have collaborated with CourseIntern Team for code snippets of the labs.

Please Go To : [GSP305: Scale Out and Update a Containerized Application on a Kubernetes Cluster](https://www.courseintern.com/post/qwiklabs/challenge-labs/gsp305-scale-out-and-update-a-containerized-application-on-a-kubernetes-cluster/)

YouTube Video Solution : [Click Here](https://youtu.be/T5l5Y-YInSc)

----------------------------------------------------------------------------------------------------------------------------------------------
