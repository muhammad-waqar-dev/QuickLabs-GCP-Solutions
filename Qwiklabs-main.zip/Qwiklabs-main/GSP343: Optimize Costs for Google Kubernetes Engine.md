### GSP343: Optimize Costs for Google Kubernetes Engine :-

----------------------------------------------------------------------------------------------------------------------------------------------

We have collaborated with CourseIntern Team for code snippets of the labs.

Please Go To : [GSP343: Optimize Costs for Google Kubernetes Engine](https://www.courseintern.com/post/qwiklabs/challenge-labs/gsp343-optimize-costs-for-google-kubernetes-engine/)

YouTube Video Solution : [Click Here](https://youtu.be/ryd0JWHuxoY)

----------------------------------------------------------------------------------------------------------------------------------------------
